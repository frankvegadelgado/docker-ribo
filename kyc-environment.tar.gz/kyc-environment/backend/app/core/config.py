from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    APP_ENV: str = "development"
    APP_NAME: str = "KYC Platform"
    SECRET_KEY: str = "changeme"
    DEBUG: bool = True

    # MongoDB
    DB_URI: str = "mongodb://kycadmin:kycpassword@mongo:27017/kycdb?authSource=admin"
    DB_NAME: str = "kycdb"

    # Redis
    REDIS_URL: str = "redis://:redispassword@redis:6379/0"

    # AWS
    AWS_REGION: str = "us-east-1"
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    AWS_S3_BUCKET: str = "kyc-documents"

    # CORS
    ALLOWED_ORIGINS: str = "http://localhost:3000"

    class Config:
        env_file = ".env"


settings = Settings()
