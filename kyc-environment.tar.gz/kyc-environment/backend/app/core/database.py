"""
Database abstraction layer.

Currently uses MongoDB via Motor.
To switch to AWS Aurora (PostgreSQL), replace the Motor client with SQLAlchemy async engine.
The interface (get_db()) stays the same so routers don't change.
"""
from motor.motor_asyncio import AsyncIOMotorClient
from app.core.config import settings
import structlog

logger = structlog.get_logger()

_client: AsyncIOMotorClient | None = None


async def connect_db():
    global _client
    logger.info("Connecting to MongoDB", uri=settings.DB_URI.split("@")[-1])
    _client = AsyncIOMotorClient(settings.DB_URI)
    # Verify connection
    await _client.admin.command("ping")
    logger.info("MongoDB connected", db=settings.DB_NAME)


async def disconnect_db():
    global _client
    if _client:
        _client.close()
        logger.info("MongoDB disconnected")


def get_db():
    """Return the active database. Inject via FastAPI Depends."""
    return _client[settings.DB_NAME]


# ---------------------------------------------------------------------------
# AWS Aurora replacement stub
# ---------------------------------------------------------------------------
# from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
# from sqlalchemy.orm import sessionmaker
#
# engine = create_async_engine(settings.DB_URI, echo=settings.DEBUG)
# AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
#
# async def get_db():
#     async with AsyncSessionLocal() as session:
#         yield session
