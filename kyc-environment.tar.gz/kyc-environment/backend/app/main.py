from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import structlog

from app.core.config import settings
from app.core.database import connect_db, disconnect_db
from app.routers import customers, documents, verifications, auth

logger = structlog.get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting KYC API", env=settings.APP_ENV)
    await connect_db()
    yield
    await disconnect_db()
    logger.info("KYC API stopped")


app = FastAPI(
    title="KYC Platform API",
    description="Know Your Customer verification platform",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    lifespan=lifespan,
)

# ── CORS ──────────────────────────────────────────────────────────────────────
origins = [o.strip() for o in settings.ALLOWED_ORIGINS.split(",")]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(auth.router,          prefix="/api/auth",          tags=["Auth"])
app.include_router(customers.router,     prefix="/api/customers",     tags=["Customers"])
app.include_router(documents.router,     prefix="/api/documents",     tags=["Documents"])
app.include_router(verifications.router, prefix="/api/verifications", tags=["Verifications"])


@app.get("/health", tags=["Health"])
async def health():
    return {"status": "ok", "env": settings.APP_ENV}
