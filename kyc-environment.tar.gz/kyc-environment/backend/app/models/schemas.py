from pydantic import BaseModel, EmailStr, Field
from typing import Optional, Literal
from datetime import datetime
from bson import ObjectId


class PyObjectId(str):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return str(v)


# ── Customer ──────────────────────────────────────────────────────────────────
class CustomerBase(BaseModel):
    first_name: str
    last_name: str
    email: EmailStr
    phone: Optional[str] = None
    date_of_birth: Optional[str] = None
    nationality: Optional[str] = None
    address: Optional[str] = None

class CustomerCreate(CustomerBase):
    pass

class CustomerOut(CustomerBase):
    id: str = Field(alias="_id")
    kyc_status: str = "pending"
    created_at: datetime
    updated_at: datetime

    class Config:
        populate_by_name = True


# ── Document ──────────────────────────────────────────────────────────────────
DocumentType = Literal["passport", "drivers_license", "national_id", "utility_bill"]

class DocumentCreate(BaseModel):
    customer_id: str
    document_type: DocumentType
    s3_key: Optional[str] = None

class DocumentOut(DocumentCreate):
    id: str = Field(alias="_id")
    status: str = "uploaded"
    created_at: datetime

    class Config:
        populate_by_name = True


# ── Verification ──────────────────────────────────────────────────────────────
VerificationStatus = Literal["pending", "in_progress", "approved", "rejected", "requires_review"]

class VerificationCreate(BaseModel):
    customer_id: str
    notes: Optional[str] = None

class VerificationOut(VerificationCreate):
    id: str = Field(alias="_id")
    status: VerificationStatus = "pending"
    risk_score: Optional[float] = None
    reviewed_by: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        populate_by_name = True


# ── Auth ──────────────────────────────────────────────────────────────────────
class UserLogin(BaseModel):
    email: EmailStr
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
