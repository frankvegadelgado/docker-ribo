from fastapi import APIRouter, Depends, HTTPException, status
from datetime import datetime, timezone
from bson import ObjectId
from app.core.database import get_db
from app.models.schemas import CustomerCreate, CustomerOut

router = APIRouter()


def _serialize(doc: dict) -> dict:
    doc["_id"] = str(doc["_id"])
    return doc


@router.post("/", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_customer(payload: CustomerCreate, db=Depends(get_db)):
    now = datetime.now(timezone.utc)
    doc = payload.model_dump()
    doc.update({"kyc_status": "pending", "created_at": now, "updated_at": now})
    result = await db.customers.insert_one(doc)
    doc["_id"] = str(result.inserted_id)
    return doc


@router.get("/", response_model=list)
async def list_customers(skip: int = 0, limit: int = 50, db=Depends(get_db)):
    cursor = db.customers.find().skip(skip).limit(limit)
    return [_serialize(c) async for c in cursor]


@router.get("/{customer_id}", response_model=dict)
async def get_customer(customer_id: str, db=Depends(get_db)):
    doc = await db.customers.find_one({"_id": ObjectId(customer_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Customer not found")
    return _serialize(doc)


@router.put("/{customer_id}", response_model=dict)
async def update_customer(customer_id: str, payload: CustomerCreate, db=Depends(get_db)):
    update = payload.model_dump(exclude_unset=True)
    update["updated_at"] = datetime.now(timezone.utc)
    result = await db.customers.find_one_and_update(
        {"_id": ObjectId(customer_id)},
        {"$set": update},
        return_document=True,
    )
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found")
    return _serialize(result)


@router.delete("/{customer_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_customer(customer_id: str, db=Depends(get_db)):
    result = await db.customers.delete_one({"_id": ObjectId(customer_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Customer not found")
