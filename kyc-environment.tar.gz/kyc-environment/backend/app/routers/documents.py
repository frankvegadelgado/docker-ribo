from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from datetime import datetime, timezone
from bson import ObjectId
import boto3
from botocore.exceptions import ClientError
import uuid

from app.core.database import get_db
from app.core.config import settings

router = APIRouter()


def _s3_client():
    if not settings.AWS_ACCESS_KEY_ID:
        return None
    return boto3.client(
        "s3",
        region_name=settings.AWS_REGION,
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
    )


@router.post("/upload")
async def upload_document(
    customer_id: str = Form(...),
    document_type: str = Form(...),
    file: UploadFile = File(...),
    db=Depends(get_db),
):
    s3_key = None
    s3 = _s3_client()

    if s3:
        s3_key = f"documents/{customer_id}/{document_type}/{uuid.uuid4()}_{file.filename}"
        try:
            s3.upload_fileobj(file.file, settings.AWS_S3_BUCKET, s3_key)
        except ClientError as e:
            raise HTTPException(status_code=500, detail=f"S3 upload failed: {e}")
    else:
        # Local dev: store metadata only
        s3_key = f"local/{customer_id}/{document_type}/{file.filename}"

    now = datetime.now(timezone.utc)
    doc = {
        "customer_id": customer_id,
        "document_type": document_type,
        "s3_key": s3_key,
        "filename": file.filename,
        "status": "uploaded",
        "created_at": now,
    }
    result = await db.documents.insert_one(doc)
    doc["_id"] = str(result.inserted_id)
    return doc


@router.get("/customer/{customer_id}")
async def list_customer_documents(customer_id: str, db=Depends(get_db)):
    cursor = db.documents.find({"customer_id": customer_id})
    docs = []
    async for d in cursor:
        d["_id"] = str(d["_id"])
        docs.append(d)
    return docs


@router.get("/{document_id}")
async def get_document(document_id: str, db=Depends(get_db)):
    doc = await db.documents.find_one({"_id": ObjectId(document_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    doc["_id"] = str(doc["_id"])
    return doc
