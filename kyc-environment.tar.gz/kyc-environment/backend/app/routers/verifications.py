from fastapi import APIRouter, Depends, HTTPException
from datetime import datetime, timezone
from bson import ObjectId
import random

from app.core.database import get_db
from app.models.schemas import VerificationCreate

router = APIRouter()


@router.post("/")
async def start_verification(payload: VerificationCreate, db=Depends(get_db)):
    now = datetime.now(timezone.utc)
    doc = {
        **payload.model_dump(),
        "status": "in_progress",
        "risk_score": None,
        "reviewed_by": None,
        "created_at": now,
        "updated_at": now,
    }
    result = await db.verifications.insert_one(doc)
    doc["_id"] = str(result.inserted_id)
    return doc


@router.get("/{verification_id}")
async def get_verification(verification_id: str, db=Depends(get_db)):
    doc = await db.verifications.find_one({"_id": ObjectId(verification_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Verification not found")
    doc["_id"] = str(doc["_id"])
    return doc


@router.put("/{verification_id}/review")
async def review_verification(
    verification_id: str,
    status: str,
    reviewed_by: str = "system",
    notes: str = "",
    db=Depends(get_db),
):
    allowed = {"approved", "rejected", "requires_review"}
    if status not in allowed:
        raise HTTPException(status_code=400, detail=f"Status must be one of {allowed}")

    # Simulate risk scoring
    risk_score = round(random.uniform(0.0, 1.0), 2)

    now = datetime.now(timezone.utc)
    result = await db.verifications.find_one_and_update(
        {"_id": ObjectId(verification_id)},
        {"$set": {
            "status": status,
            "risk_score": risk_score,
            "reviewed_by": reviewed_by,
            "notes": notes,
            "updated_at": now,
        }},
        return_document=True,
    )
    if not result:
        raise HTTPException(status_code=404, detail="Verification not found")

    # Update parent customer status
    await db.customers.update_one(
        {"_id": ObjectId(result["customer_id"])},
        {"$set": {"kyc_status": status, "updated_at": now}},
    )

    result["_id"] = str(result["_id"])
    return result


@router.get("/customer/{customer_id}")
async def list_customer_verifications(customer_id: str, db=Depends(get_db)):
    cursor = db.verifications.find({"customer_id": customer_id})
    docs = []
    async for d in cursor:
        d["_id"] = str(d["_id"])
        docs.append(d)
    return docs
