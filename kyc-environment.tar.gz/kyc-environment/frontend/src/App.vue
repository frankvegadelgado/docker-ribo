<template>
  <div id="app-shell">
    <!-- Sidebar -->
    <aside class="sidebar" v-if="authStore.isAuthenticated">
      <div class="sidebar-brand">
        <span class="brand-icon">⬡</span>
        <span class="brand-name">KYC<em>Platform</em></span>
      </div>
      <nav class="sidebar-nav">
        <RouterLink to="/dashboard" class="nav-item">
          <span class="nav-icon">◈</span> Dashboard
        </RouterLink>
        <RouterLink to="/customers" class="nav-item">
          <span class="nav-icon">◉</span> Customers
        </RouterLink>
        <RouterLink to="/verifications" class="nav-item">
          <span class="nav-icon">◎</span> Verifications
        </RouterLink>
        <RouterLink to="/documents" class="nav-item">
          <span class="nav-icon">▣</span> Documents
        </RouterLink>
      </nav>
      <div class="sidebar-footer">
        <span class="user-badge">{{ authStore.userEmail }}</span>
        <button class="logout-btn" @click="authStore.logout">Logout</button>
      </div>
    </aside>

    <!-- Main content -->
    <main class="main-content">
      <RouterView />
    </main>
  </div>
</template>

<script setup>
import { RouterView, RouterLink } from 'vue-router'
import { useAuthStore } from '@/store/auth'

const authStore = useAuthStore()
</script>
