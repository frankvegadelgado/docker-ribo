import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000',
  timeout: 15000,
})

// Attach token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('kyc_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// Handle 401 globally
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('kyc_token')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export default api

// ── Resource helpers ──────────────────────────────────────────────────────────
export const authApi = {
  login: (email, password) =>
    api.post('/api/auth/token', new URLSearchParams({ username: email, password }),
      { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }),
  me: () => api.get('/api/auth/me'),
}

export const customersApi = {
  list:   (params) => api.get('/api/customers/', { params }),
  get:    (id)     => api.get(`/api/customers/${id}`),
  create: (data)   => api.post('/api/customers/', data),
  update: (id, data) => api.put(`/api/customers/${id}`, data),
  remove: (id)     => api.delete(`/api/customers/${id}`),
}

export const documentsApi = {
  listByCustomer: (customerId) => api.get(`/api/documents/customer/${customerId}`),
  upload: (formData) => api.post('/api/documents/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
}

export const verificationsApi = {
  start:          (data)       => api.post('/api/verifications/', data),
  get:            (id)         => api.get(`/api/verifications/${id}`),
  review:         (id, params) => api.put(`/api/verifications/${id}/review`, null, { params }),
  listByCustomer: (customerId) => api.get(`/api/verifications/customer/${customerId}`),
}
