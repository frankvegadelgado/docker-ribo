import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { authApi } from './api'
import router from '@/router'

export const useAuthStore = defineStore('auth', () => {
  const token = ref(localStorage.getItem('kyc_token') || '')
  const user  = ref(null)

  const isAuthenticated = computed(() => !!token.value)
  const userEmail       = computed(() => user.value?.email || '')

  async function login(email, password) {
    const { data } = await authApi.login(email, password)
    token.value = data.access_token
    localStorage.setItem('kyc_token', data.access_token)
    const me = await authApi.me()
    user.value = me.data
    router.push('/dashboard')
  }

  function logout() {
    token.value = ''
    user.value  = null
    localStorage.removeItem('kyc_token')
    router.push('/login')
  }

  async function fetchMe() {
    if (!token.value) return
    try {
      const { data } = await authApi.me()
      user.value = data
    } catch {
      logout()
    }
  }

  return { token, user, isAuthenticated, userEmail, login, logout, fetchMe }
})
