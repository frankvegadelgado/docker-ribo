<template>
  <div>
    <div class="page-header">
      <div style="display:flex; align-items:center; gap:12px">
        <RouterLink to="/customers" class="btn btn-ghost btn-sm">← Back</RouterLink>
        <h1 class="page-title" v-if="customer">
          {{ customer.first_name }} {{ customer.last_name }}
          <span :class="badge(customer.kyc_status)">{{ customer.kyc_status }}</span>
        </h1>
      </div>
      <button class="btn btn-primary" v-if="customer" @click="startVerification">
        + Start Verification
      </button>
    </div>

    <div v-if="loading" class="loading">Loading…</div>
    <div v-else-if="customer" style="display:grid; grid-template-columns:1fr 1fr; gap:20px">

      <!-- Customer Info -->
      <div class="card">
        <h3 style="margin-bottom:16px; font-size:14px; color:var(--text-muted)">CUSTOMER DETAILS</h3>
        <div class="detail-row"><span>Email</span><span>{{ customer.email }}</span></div>
        <div class="detail-row"><span>Phone</span><span>{{ customer.phone || '—' }}</span></div>
        <div class="detail-row"><span>Date of Birth</span><span>{{ customer.date_of_birth || '—' }}</span></div>
        <div class="detail-row"><span>Nationality</span><span>{{ customer.nationality || '—' }}</span></div>
        <div class="detail-row"><span>Address</span><span>{{ customer.address || '—' }}</span></div>
        <div class="detail-row"><span>Created</span><span>{{ fmt(customer.created_at) }}</span></div>
      </div>

      <!-- Documents -->
      <div class="card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px">
          <h3 style="font-size:14px; color:var(--text-muted)">DOCUMENTS</h3>
          <label class="btn btn-ghost btn-sm" style="cursor:pointer">
            Upload
            <input type="file" style="display:none" @change="uploadDoc" />
          </label>
        </div>
        <select v-model="docType" style="margin-bottom:12px">
          <option value="passport">Passport</option>
          <option value="drivers_license">Driver's License</option>
          <option value="national_id">National ID</option>
          <option value="utility_bill">Utility Bill</option>
        </select>
        <div v-if="!documents.length" class="empty-state" style="padding:24px">No documents uploaded</div>
        <div v-for="d in documents" :key="d._id" class="doc-item">
          <span class="badge badge-progress">{{ d.document_type }}</span>
          <span style="font-size:12px; color:var(--text-muted)">{{ d.filename }}</span>
          <span class="badge badge-approved">{{ d.status }}</span>
        </div>
      </div>

      <!-- Verifications -->
      <div class="card" style="grid-column: 1 / -1">
        <h3 style="margin-bottom:16px; font-size:14px; color:var(--text-muted)">VERIFICATIONS</h3>
        <div v-if="!verifications.length" class="empty-state">No verifications yet</div>
        <table v-else>
          <thead>
            <tr><th>ID</th><th>Status</th><th>Risk Score</th><th>Reviewed By</th><th>Created</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <tr v-for="v in verifications" :key="v._id">
              <td style="font-family:var(--font-mono); font-size:11px">{{ v._id.slice(-8) }}</td>
              <td><span :class="badge(v.status)">{{ v.status }}</span></td>
              <td>{{ v.risk_score !== null ? v.risk_score : '—' }}</td>
              <td>{{ v.reviewed_by || '—' }}</td>
              <td>{{ fmt(v.created_at) }}</td>
              <td v-if="v.status === 'in_progress' || v.status === 'pending'">
                <button class="btn btn-ghost btn-sm" style="color:var(--accent)" @click="review(v._id, 'approved')">Approve</button>
                <button class="btn btn-ghost btn-sm" style="color:var(--danger); margin-left:6px" @click="review(v._id, 'rejected')">Reject</button>
              </td>
              <td v-else>—</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { RouterLink, useRoute } from 'vue-router'
import { customersApi, documentsApi, verificationsApi } from '@/store/api'

const route         = useRoute()
const customer      = ref(null)
const documents     = ref([])
const verifications = ref([])
const loading       = ref(true)
const docType       = ref('passport')

function badge(s) {
  return { badge:true, 'badge-pending': s==='pending', 'badge-approved': s==='approved',
           'badge-rejected': s==='rejected', 'badge-review': s==='requires_review', 'badge-progress': s==='in_progress' }
}
function fmt(d) { return d ? new Date(d).toLocaleDateString() : '—' }

async function load() {
  const id = route.params.id
  try {
    const [c, d, v] = await Promise.all([
      customersApi.get(id),
      documentsApi.listByCustomer(id),
      verificationsApi.listByCustomer(id),
    ])
    customer.value      = c.data
    documents.value     = d.data
    verifications.value = v.data
  } finally { loading.value = false }
}

async function startVerification() {
  const { data } = await verificationsApi.start({ customer_id: route.params.id })
  verifications.value.unshift(data)
}

async function review(vId, status) {
  const { data } = await verificationsApi.review(vId, { status, reviewed_by: 'officer@kyc.local' })
  const idx = verifications.value.findIndex(v => v._id === vId)
  if (idx !== -1) verifications.value[idx] = data
  const c = await customersApi.get(route.params.id)
  customer.value = c.data
}

async function uploadDoc(e) {
  const file = e.target.files[0]
  if (!file) return
  const fd = new FormData()
  fd.append('customer_id', route.params.id)
  fd.append('document_type', docType.value)
  fd.append('file', file)
  const { data } = await documentsApi.upload(fd)
  documents.value.push(data)
}

onMounted(load)
</script>

<style scoped>
.detail-row {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid var(--border);
  font-size: 13px;
}
.detail-row > span:first-child { color: var(--text-muted); }
.detail-row:last-child { border-bottom: none; }
.doc-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 0;
  border-bottom: 1px solid var(--border);
}
.doc-item:last-child { border-bottom: none; }
</style>
