<template>
  <div>
    <div class="page-header">
      <h1 class="page-title">Customers <span>Registry</span></h1>
      <button class="btn btn-primary" @click="showModal = true">+ New Customer</button>
    </div>

    <div class="card">
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Name</th><th>Email</th><th>Phone</th><th>Nationality</th>
              <th>KYC Status</th><th>Created</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="loading"><td colspan="7" class="loading">Loading…</td></tr>
            <tr v-else-if="!customers.length"><td colspan="7" class="empty-state">No customers — add one above</td></tr>
            <tr v-for="c in customers" :key="c._id">
              <td>
                <RouterLink :to="`/customers/${c._id}`" style="color:var(--accent2); font-weight:600">
                  {{ c.first_name }} {{ c.last_name }}
                </RouterLink>
              </td>
              <td>{{ c.email }}</td>
              <td>{{ c.phone || '—' }}</td>
              <td>{{ c.nationality || '—' }}</td>
              <td><span :class="badge(c.kyc_status)">{{ c.kyc_status }}</span></td>
              <td>{{ fmt(c.created_at) }}</td>
              <td>
                <RouterLink :to="`/customers/${c._id}`" class="btn btn-ghost btn-sm">View</RouterLink>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Create Modal -->
    <div class="modal-overlay" v-if="showModal" @click.self="showModal = false">
      <div class="modal">
        <h3 class="modal-title">New Customer</h3>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:0 16px">
          <div class="form-group">
            <label>First Name *</label>
            <input v-model="form.first_name" placeholder="John" />
          </div>
          <div class="form-group">
            <label>Last Name *</label>
            <input v-model="form.last_name" placeholder="Doe" />
          </div>
        </div>
        <div class="form-group">
          <label>Email *</label>
          <input v-model="form.email" type="email" placeholder="john@example.com" />
        </div>
        <div class="form-group">
          <label>Phone</label>
          <input v-model="form.phone" placeholder="+1 555 000 0000" />
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:0 16px">
          <div class="form-group">
            <label>Date of Birth</label>
            <input v-model="form.date_of_birth" type="date" />
          </div>
          <div class="form-group">
            <label>Nationality</label>
            <input v-model="form.nationality" placeholder="US" />
          </div>
        </div>
        <div class="form-group">
          <label>Address</label>
          <input v-model="form.address" placeholder="123 Main St, Miami FL" />
        </div>
        <p v-if="formError" class="error-msg">{{ formError }}</p>
        <div style="display:flex; gap:12px; justify-content:flex-end; margin-top:8px">
          <button class="btn btn-ghost" @click="showModal = false">Cancel</button>
          <button class="btn btn-primary" @click="createCustomer" :disabled="saving">
            {{ saving ? 'Creating…' : 'Create' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { RouterLink } from 'vue-router'
import { customersApi } from '@/store/api'

const customers = ref([])
const loading   = ref(true)
const showModal = ref(false)
const saving    = ref(false)
const formError = ref('')
const form = ref({ first_name:'', last_name:'', email:'', phone:'', date_of_birth:'', nationality:'', address:'' })

function badge(s) {
  return { badge:true, 'badge-pending': s==='pending', 'badge-approved': s==='approved',
           'badge-rejected': s==='rejected', 'badge-review': s==='requires_review', 'badge-progress': s==='in_progress' }
}
function fmt(d) { return d ? new Date(d).toLocaleDateString() : '—' }

async function load() {
  try { const { data } = await customersApi.list(); customers.value = data }
  finally { loading.value = false }
}

async function createCustomer() {
  formError.value = ''
  if (!form.value.first_name || !form.value.last_name || !form.value.email) {
    formError.value = 'First name, last name, and email are required'; return
  }
  saving.value = true
  try {
    const { data } = await customersApi.create(form.value)
    customers.value.unshift(data)
    showModal.value = false
    form.value = { first_name:'', last_name:'', email:'', phone:'', date_of_birth:'', nationality:'', address:'' }
  } catch(e) {
    formError.value = e.response?.data?.detail || 'Failed to create customer'
  } finally { saving.value = false }
}

onMounted(load)
</script>
