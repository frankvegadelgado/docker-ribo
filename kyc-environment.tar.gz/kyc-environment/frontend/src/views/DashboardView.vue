<template>
  <div>
    <div class="page-header">
      <h1 class="page-title">Dashboard <span>Overview</span></h1>
      <span class="badge badge-pending" style="font-size:12px">Live</span>
    </div>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-label">Total Customers</div>
        <div class="stat-value">{{ stats.total }}</div>
      </div>
      <div class="stat-card warn">
        <div class="stat-label">Pending KYC</div>
        <div class="stat-value">{{ stats.pending }}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Approved</div>
        <div class="stat-value">{{ stats.approved }}</div>
      </div>
      <div class="stat-card danger">
        <div class="stat-label">Rejected</div>
        <div class="stat-value">{{ stats.rejected }}</div>
      </div>
      <div class="stat-card info">
        <div class="stat-label">Under Review</div>
        <div class="stat-value">{{ stats.review }}</div>
      </div>
    </div>

    <div class="card">
      <div class="page-header" style="margin-bottom:16px">
        <strong>Recent Customers</strong>
        <RouterLink to="/customers" class="btn btn-ghost btn-sm">View all →</RouterLink>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Name</th><th>Email</th><th>Nationality</th><th>KYC Status</th><th>Created</th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="loading"><td colspan="5" class="loading">Loading…</td></tr>
            <tr v-else-if="!customers.length"><td colspan="5" class="empty-state">No customers yet</td></tr>
            <tr v-for="c in customers.slice(0, 8)" :key="c._id">
              <td>
                <RouterLink :to="`/customers/${c._id}`" style="color:var(--accent2)">
                  {{ c.first_name }} {{ c.last_name }}
                </RouterLink>
              </td>
              <td>{{ c.email }}</td>
              <td>{{ c.nationality || '—' }}</td>
              <td><span :class="statusBadge(c.kyc_status)">{{ c.kyc_status }}</span></td>
              <td>{{ fmtDate(c.created_at) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { RouterLink } from 'vue-router'
import { customersApi } from '@/store/api'

const customers = ref([])
const loading   = ref(true)

const stats = computed(() => ({
  total:    customers.value.length,
  pending:  customers.value.filter(c => c.kyc_status === 'pending').length,
  approved: customers.value.filter(c => c.kyc_status === 'approved').length,
  rejected: customers.value.filter(c => c.kyc_status === 'rejected').length,
  review:   customers.value.filter(c => c.kyc_status === 'requires_review').length,
}))

function statusBadge(s) {
  return {
    badge: true,
    'badge-pending':  s === 'pending',
    'badge-approved': s === 'approved',
    'badge-rejected': s === 'rejected',
    'badge-review':   s === 'requires_review',
    'badge-progress': s === 'in_progress',
  }
}
function fmtDate(d) {
  return d ? new Date(d).toLocaleDateString() : '—'
}

onMounted(async () => {
  try {
    const { data } = await customersApi.list({ limit: 50 })
    customers.value = data
  } finally {
    loading.value = false
  }
})
</script>
