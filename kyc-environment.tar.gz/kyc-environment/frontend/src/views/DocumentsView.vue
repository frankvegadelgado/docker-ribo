<template>
  <div>
    <div class="page-header">
      <h1 class="page-title">Documents <span>Store</span></h1>
    </div>
    <div class="card">
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Document ID</th><th>Customer</th><th>Type</th><th>File</th><th>S3 Key</th><th>Status</th><th>Uploaded</th></tr>
          </thead>
          <tbody>
            <tr v-if="loading"><td colspan="7" class="loading">Loading…</td></tr>
            <tr v-else-if="!docs.length"><td colspan="7" class="empty-state">No documents found</td></tr>
            <tr v-for="d in docs" :key="d._id">
              <td style="font-family:var(--font-mono); font-size:11px">{{ d._id.slice(-10) }}</td>
              <td>
                <RouterLink :to="`/customers/${d.customer_id}`" style="color:var(--accent2)">
                  {{ d.customer_id.slice(-8) }}
                </RouterLink>
              </td>
              <td><span class="badge badge-progress">{{ d.document_type }}</span></td>
              <td style="font-size:12px">{{ d.filename }}</td>
              <td style="font-family:var(--font-mono); font-size:10px; color:var(--text-muted); max-width:180px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap">
                {{ d.s3_key }}
              </td>
              <td><span class="badge badge-approved">{{ d.status }}</span></td>
              <td>{{ fmt(d.created_at) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { RouterLink } from 'vue-router'
import { customersApi, documentsApi } from '@/store/api'

const docs    = ref([])
const loading = ref(true)

function fmt(d) { return d ? new Date(d).toLocaleDateString() : '—' }

onMounted(async () => {
  try {
    const { data: customers } = await customersApi.list({ limit: 100 })
    const all = await Promise.all(
      customers.map(c => documentsApi.listByCustomer(c._id).then(r => r.data))
    )
    docs.value = all.flat().sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
  } finally { loading.value = false }
})
</script>
