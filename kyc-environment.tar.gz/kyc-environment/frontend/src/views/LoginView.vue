<template>
  <div class="login-page">
    <div class="login-left">
      <div class="login-hero">
        <div class="hero-glyph">⬡</div>
        <h1>KYC<em>Platform</em></h1>
        <p>Know Your Customer — identity verification &amp; compliance operations</p>
      </div>
    </div>

    <div class="login-right">
      <div class="login-box">
        <h2>Sign in</h2>
        <p class="login-hint">Use <code>admin@kyc.local / admin123</code></p>

        <div class="form-group">
          <label>Email</label>
          <input v-model="email" type="email" placeholder="you@kyc.local" @keyup.enter="submit" />
        </div>
        <div class="form-group">
          <label>Password</label>
          <input v-model="password" type="password" placeholder="••••••••" @keyup.enter="submit" />
        </div>

        <p v-if="error" class="error-msg">{{ error }}</p>

        <button class="btn btn-primary" style="width:100%; margin-top:8px" @click="submit" :disabled="loading">
          {{ loading ? 'Signing in…' : 'Sign in' }}
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useAuthStore } from '@/store/auth'

const authStore = useAuthStore()
const email    = ref('')
const password = ref('')
const error    = ref('')
const loading  = ref(false)

async function submit() {
  error.value = ''
  loading.value = true
  try {
    await authStore.login(email.value, password.value)
  } catch (e) {
    error.value = e.response?.data?.detail || 'Login failed'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-page {
  display: flex;
  min-height: 100vh;
}
.login-left {
  flex: 1;
  background: linear-gradient(135deg, #0d1117 0%, #111827 50%, #0a1628 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px;
  border-right: 1px solid var(--border);
}
.login-hero { max-width: 360px; }
.hero-glyph { font-size: 64px; color: var(--accent); margin-bottom: 16px; }
.login-hero h1 { font-size: 40px; font-weight: 800; letter-spacing: -1px; }
.login-hero h1 em { color: var(--accent); font-style: normal; }
.login-hero p { color: var(--text-muted); margin-top: 12px; line-height: 1.7; }

.login-right {
  width: 420px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px 32px;
}
.login-box { width: 100%; }
.login-box h2 { font-size: 24px; font-weight: 700; margin-bottom: 8px; }
.login-hint { font-size: 12px; color: var(--text-muted); margin-bottom: 24px; }
.login-hint code {
  background: var(--surface2);
  padding: 2px 6px;
  border-radius: 4px;
  color: var(--accent);
  font-size: 11px;
}

@media (max-width: 768px) {
  .login-left { display: none; }
  .login-right { width: 100%; }
}
</style>
