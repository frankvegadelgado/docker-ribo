<template>
  <div>
    <div class="page-header">
      <h1 class="page-title">Verifications <span>Queue</span></h1>
    </div>
    <div class="card">
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Verification ID</th><th>Customer ID</th><th>Status</th><th>Risk Score</th><th>Reviewed By</th><th>Date</th></tr>
          </thead>
          <tbody>
            <tr v-if="loading"><td colspan="6" class="loading">Loading…</td></tr>
            <tr v-else-if="!items.length"><td colspan="6" class="empty-state">No verifications found</td></tr>
            <tr v-for="v in items" :key="v._id">
              <td style="font-family:var(--font-mono); font-size:11px">{{ v._id }}</td>
              <td style="font-family:var(--font-mono); font-size:11px">
                <RouterLink :to="`/customers/${v.customer_id}`" style="color:var(--accent2)">
                  {{ v.customer_id.slice(-8) }}
                </RouterLink>
              </td>
              <td><span :class="badge(v.status)">{{ v.status }}</span></td>
              <td>
                <span v-if="v.risk_score !== null" :style="riskColor(v.risk_score)">
                  {{ (v.risk_score * 100).toFixed(0) }}%
                </span>
                <span v-else>—</span>
              </td>
              <td>{{ v.reviewed_by || '—' }}</td>
              <td>{{ fmt(v.created_at) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { RouterLink } from 'vue-router'
import { customersApi, verificationsApi } from '@/store/api'

const items   = ref([])
const loading = ref(true)

function badge(s) {
  return { badge:true, 'badge-pending': s==='pending', 'badge-approved': s==='approved',
           'badge-rejected': s==='rejected', 'badge-review': s==='requires_review', 'badge-progress': s==='in_progress' }
}
function fmt(d) { return d ? new Date(d).toLocaleDateString() : '—' }
function riskColor(score) {
  if (score > 0.7) return { color: 'var(--danger)', fontWeight: '700' }
  if (score > 0.4) return { color: 'var(--warn)', fontWeight: '600' }
  return { color: 'var(--accent)' }
}

onMounted(async () => {
  try {
    // Fetch all customers then gather verifications (replace with a /verifications endpoint in prod)
    const { data: customers } = await customersApi.list({ limit: 100 })
    const all = await Promise.all(
      customers.map(c => verificationsApi.listByCustomer(c._id).then(r => r.data))
    )
    items.value = all.flat().sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
  } finally { loading.value = false }
})
</script>
