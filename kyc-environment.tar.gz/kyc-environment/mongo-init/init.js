// MongoDB initialization script
// Creates the KYC database, user, and seed collections

db = db.getSiblingDB('kycdb');

// Create app user
db.createUser({
  user: 'kycapp',
  pwd: 'kycapppassword',
  roles: [{ role: 'readWrite', db: 'kycdb' }]
});

// Create collections with schema validation
db.createCollection('customers', {
  validator: {
    $jsonSchema: {
      bsonType: 'object',
      required: ['first_name', 'last_name', 'email'],
      properties: {
        first_name:    { bsonType: 'string' },
        last_name:     { bsonType: 'string' },
        email:         { bsonType: 'string' },
        kyc_status:    { bsonType: 'string', enum: ['pending','approved','rejected','in_progress','requires_review'] },
      }
    }
  }
});

db.createCollection('documents');
db.createCollection('verifications');

// Indexes
db.customers.createIndex({ email: 1 }, { unique: true });
db.customers.createIndex({ kyc_status: 1 });
db.documents.createIndex({ customer_id: 1 });
db.verifications.createIndex({ customer_id: 1 });
db.verifications.createIndex({ status: 1 });

// Seed data
db.customers.insertMany([
  {
    first_name: 'Alice',
    last_name: 'Johnson',
    email: 'alice.johnson@example.com',
    phone: '+1 305 555 0101',
    date_of_birth: '1990-04-15',
    nationality: 'US',
    address: '100 Brickell Ave, Miami FL 33131',
    kyc_status: 'approved',
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    first_name: 'Bruno',
    last_name: 'Martinez',
    email: 'bruno.martinez@example.com',
    phone: '+1 786 555 0202',
    date_of_birth: '1985-09-22',
    nationality: 'BR',
    address: '200 NW 2nd Ave, Miami FL 33128',
    kyc_status: 'pending',
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    first_name: 'Chen',
    last_name: 'Wei',
    email: 'chen.wei@example.com',
    phone: '+1 954 555 0303',
    date_of_birth: '1992-01-08',
    nationality: 'CN',
    address: '500 Las Olas Blvd, Ft Lauderdale FL 33301',
    kyc_status: 'requires_review',
    created_at: new Date(),
    updated_at: new Date()
  }
]);

print('✅ KYC database initialized with seed data');
